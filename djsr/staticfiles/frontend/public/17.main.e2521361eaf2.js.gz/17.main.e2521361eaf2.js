(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[17],{

/***/ "./djsr/frontend/src/components/RegisterSuccess.js":
/*!*********************************************************!*\
  !*** ./djsr/frontend/src/components/RegisterSuccess.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router-dom/esm/react-router-dom.js");



function RegisterSuccess(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", null, "Pomy\u015Blnie utworzono konto u\u017Cytkownika"));
}

/* harmony default export */ __webpack_exports__["default"] = (RegisterSuccess);

/***/ })

}]);
//# sourceMappingURL=17.main.js.map