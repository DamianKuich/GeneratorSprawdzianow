(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[1],{

/***/ "./djsr/frontend/src/components/ExamEditor.js":
/*!****************************************************!*\
  !*** ./djsr/frontend/src/components/ExamEditor.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mdbreact__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! mdbreact */ "./node_modules/mdbreact/dist/mdbreact.esm.js");
/* harmony import */ var _taskSearch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./taskSearch */ "./djsr/frontend/src/components/taskSearch.js");
/* harmony import */ var react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-beautiful-dnd */ "./node_modules/react-beautiful-dnd/dist/react-beautiful-dnd.esm.js");
/* harmony import */ var _TaskEditor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./TaskEditor */ "./djsr/frontend/src/components/TaskEditor.js");
/* harmony import */ var lodash_collection__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash/collection */ "./node_modules/lodash/collection.js");
/* harmony import */ var lodash_collection__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash_collection__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_latex__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-latex */ "./node_modules/react-latex/build/latex.js");
/* harmony import */ var react_latex__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_latex__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _styles_katex_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./styles/katex.css */ "./djsr/frontend/src/components/styles/katex.css");
/* harmony import */ var _styles_katex_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_styles_katex_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _registered_files__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./registered-files */ "./djsr/frontend/src/components/registered-files.js");
/* harmony import */ var _axiosAPI__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./axiosAPI */ "./djsr/frontend/src/components/axiosAPI.js");
function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { return function () { var Super = _getPrototypeOf(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // import PropTypes from "prop-types";




 // import {
//   PDFDownloadLink,
//   Document,
//   Page,
//   Text,
//   StyleSheet,
//   View,
//   Font,
//   Image,
//   Svg,
//   Path,
//   G,
// } from "@react-pdf/renderer";

 // import Roboto from "./webfonts/Roboto-Regular.ttf";
// import RobotoBold from "./webfonts/Roboto-Bold.ttf";



 // import examToPdf from "./ExamPDF";



var ExamEditor = /*#__PURE__*/function (_Component) {
  _inherits(ExamEditor, _Component);

  var _super = _createSuper(ExamEditor);

  function ExamEditor(props) {
    var _this;

    _classCallCheck(this, ExamEditor);

    _this = _super.call(this, props);

    _defineProperty(_assertThisInitialized(_this), "resetTimeout", function (id, newID) {
      clearTimeout(id);
      return newID;
    });

    _defineProperty(_assertThisInitialized(_this), "getExam", function () {
      var id = _this.props.match.params.id;
      _axiosAPI__WEBPACK_IMPORTED_MODULE_9__["default"].get("/user/onetest/".concat(id)).then(function (response) {
        console.log(response);

        _this.setState(function (state) {
          state.exam = response.data[0];

          if (state.exam.tasks.length > 0) {
            state.exam.tasks = JSON.parse(state.exam.tasks);
          } else {
            state.exam.tasks = [];
          }

          return state;
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "generatedPDFV3", function () {});

    _defineProperty(_assertThisInitialized(_this), "setTaskToEdit", function (index) {
      _this.setState(function (state) {
        state.editorTask = state.exam.tasks[index];
        state.sideMenuCollapseId = "taskEdit";
        return state;
      });
    });

    _defineProperty(_assertThisInitialized(_this), "updateTaskToEdit", function (task) {
      _this.setState(function (state) {
        Object.assign(state.editorTask, task);
        state.timeout = _this.resetTimeout(_this.state.timeout, setTimeout(_this.saveExam, 3000));
        state.saved = false;
        return state;
      });
    });

    _defineProperty(_assertThisInitialized(_this), "saveExam", function () {
      _axiosAPI__WEBPACK_IMPORTED_MODULE_9__["default"].put("/user/maketest/", {
        id: _this.state.exam.id,
        tasks: JSON.stringify(_this.state.exam.tasks)
      }).then(function (response) {
        _this.setState({
          saved: true
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "removeTask", function (index) {
      _this.setState(function (state) {
        if (index === 0) {
          state.exam.tasks.shift();
        } else {
          state.exam.tasks.splice(index, index);
        }

        state.timeout = _this.resetTimeout(_this.state.timeout, setTimeout(_this.saveExam, 3000));
        state.saved = false;
        return state;
      });
    });

    _defineProperty(_assertThisInitialized(_this), "dragEnd", function (result) {
      var source = result.source,
          destination = result.destination,
          draggableId = result.draggableId;
      console.log(source, destination, draggableId);

      if (source.droppableId === "examDroppable" && !destination.droppableId) {
        _this.setState(function (state) {
          state.exam.tasks = state.exam.tasks.splice(source.index, source.index);
          return state;
        });
      }

      console.log("dragEnd", result);

      if (!destination || destination.droppableId === "searchDroppable") {
        return;
      }

      if (source.droppableId === "examDroppable" && destination.droppableId === "examDroppable") {
        _this.setState(function (state) {
          var tasks = state.exam.tasks;
          var _ref = [tasks[destination.index], tasks[source.index]];
          tasks[source.index] = _ref[0];
          tasks[destination.index] = _ref[1];
          state.saved = false;
          state.timeout = _this.resetTimeout(_this.state.timeout, setTimeout(_this.saveExam, 3000));
          return state;
        });
      } else {
        var draggedItem = JSON.parse(JSON.stringify(_this.state.tasks[source.index]));
        draggedItem.currentDataSet = draggedItem.dataset[0];
        var currentDataSetAnswers = draggedItem.currentDataSet.answers[0];
        console.log("XD?", currentDataSetAnswers.allanswers.replace(/'/g, '"'));
        currentDataSetAnswers.allanswers = JSON.parse(currentDataSetAnswers.allanswers.replace(/'/g, '"'));
        currentDataSetAnswers.correctans = JSON.parse(currentDataSetAnswers.correctans.replace(/'/g, '"'));
        console.log(currentDataSetAnswers, "currentDataSetAnswers");
        var correctAnswersIndex = [Math.floor(Math.random() * (currentDataSetAnswers.correctans.length - 1))];
        console.log(correctAnswersIndex, "correctAnswersIndex", currentDataSetAnswers.length);
        var incorrectAnswersIndexes = currentDataSetAnswers.allanswers.map(function (item, index) {
          return index;
        });
        var answersSet = []; // [sampleSize(currentDataSetAnswers.allanswers,3).map];

        answersSet = answersSet.concat(Object(lodash_collection__WEBPACK_IMPORTED_MODULE_5__["sampleSize"])(correctAnswersIndex).map(function (item) {
          return {
            index: item,
            isCorrect: true
          };
        }));
        answersSet = answersSet.concat(Object(lodash_collection__WEBPACK_IMPORTED_MODULE_5__["sampleSize"])(incorrectAnswersIndexes, 3).map(function (item) {
          return {
            index: item,
            isCorrect: false
          };
        }));
        answersSet = Object(lodash_collection__WEBPACK_IMPORTED_MODULE_5__["shuffle"])(answersSet);
        draggedItem.currentDataSet.examAnswers = answersSet;
        draggedItem.maxPoints = 1;
        console.log("draggedItem", draggedItem, _this.state.tasks);

        _this.setState(function (state) {
          state.exam.tasks.splice(destination.index, 0, draggedItem);
          state.saved = false;
          state.timeout = _this.resetTimeout(_this.state.timeout, setTimeout(_this.saveExam, 3000));
          return state;
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "setSearchedTasks", function (tasks) {
      _this.setState(function (state) {
        state.tasks = tasks;
        return state;
      });
    });

    _defineProperty(_assertThisInitialized(_this), "setSideMenuCollapse", function (collapseId) {
      _this.setState({
        sideMenuCollapseId: collapseId
      });
    });

    _this.state = {
      exam: null,
      //     {
      //   tasks: [],
      // }
      tasks: null,
      sideMenuCollapseId: "",
      editorTask: null,
      timeout: null,
      saved: true
    };
    return _this;
  }

  _createClass(ExamEditor, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      this.getExam();
    }
  }, {
    key: "render",
    value: function render() {
      var _this2 = this;

      var exam = this.state.exam;

      if (!exam) {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_1__["MDBContainer"], null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, "Ladowanie"));
      }

      var sideMenuCollapseId = this.state.sideMenuCollapseId;
      var searchedTasks = this.state.tasks;
      var examTasks = this.state.exam.tasks;
      var editorTask = this.state.editorTask;
      console.log("editorTask", editorTask);
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_3__["DragDropContext"], {
        onDragEnd: this.dragEnd
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_1__["MDBRow"], null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_1__["MDBCol"], {
        size: "4",
        className: "border-right"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "w-100 h2-responsive text-center"
      }, exam.name), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "w-100 text-right"
      }, this.state.saved ? "Zapisano" : "Zapisywanie"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_1__["MDBRow"], null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_1__["MDBCol"], {
        className: "d-flex justify-content-between " + "p-2 mt-3 border-right border-top border-left " + (sideMenuCollapseId === "taskSearch" ? "" : "border-bottom"),
        onClick: function onClick() {
          _this2.setSideMenuCollapse("taskSearch");
        }
      }, "Dodaj zadanie"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_1__["MDBCol"], {
        size: "3",
        className: "d-flex justify-content-between " + "p-2 mt-3 border-right border-top border-left " + (sideMenuCollapseId === "taskEdit" ? "" : "border-bottom"),
        onClick: function onClick() {
          _this2.setSideMenuCollapse("taskEdit");
        }
      }, "Edycja zadania"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_1__["MDBCol"], {
        size: "3",
        className: "d-flex justify-content-between " + "p-2 mt-3 border-right border-top border-left border-bottom"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        onClick: function onClick() {
          _this2.generatedPDFV3(_this2.state.exam);
        }
      }, "Pobierz PDF"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_1__["MDBCollapse"], {
        id: "taskSearch",
        isOpen: sideMenuCollapseId,
        className: "w-100"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_taskSearch__WEBPACK_IMPORTED_MODULE_2__["default"], {
        updateData: this.setSearchedTasks
      }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_1__["MDBContainer"], {
        className: "mt-3"
      }, Array.isArray(searchedTasks) && searchedTasks.length > 0 && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_3__["Droppable"], {
        droppableId: "searchDroppable"
      }, function (provided, snapshot) {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          ref: provided.innerRef,
          style: {
            backgroundColor: snapshot.isDraggingOver ? "red" : "white"
          },
          className: "border-top"
        }, searchedTasks.map(function (task, index) {
          return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_3__["Draggable"], {
            key: "task-" + task.id,
            draggableId: "" + task.id,
            index: index
          }, function (provided, snapshot) {
            return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", _extends({
              ref: provided.innerRef
            }, provided.draggableProps, provided.dragHandleProps, {
              style: provided.draggableProps.style,
              className: "border-right border-left border-bottom p-2"
            }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_latex__WEBPACK_IMPORTED_MODULE_6___default.a, null, task.text));
          });
        }), provided.placeholder);
      }), Array.isArray(searchedTasks) && searchedTasks.length === 0 && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, "Brak zada\u0144 o podanych kryteriach"), !searchedTasks && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "text-truncate"
      }, "Wybierz umiejetnosci z listy. Aby doda\u0107 zadania do sprawdzianu przeci\u0105gnij je na sprawdzian"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_1__["MDBCollapse"], {
        id: "taskEdit",
        isOpen: sideMenuCollapseId,
        className: "w-100"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_TaskEditor__WEBPACK_IMPORTED_MODULE_4__["default"], {
        task: editorTask,
        updateTask: this.updateTaskToEdit
      }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_1__["MDBCol"], {
        size: "8",
        className: "d-flex justify-content-center"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_3__["Droppable"], {
        droppableId: "examDroppable",
        style: {
          marginLeft: "auto",
          marginRight: "auto"
        }
      }, function (provided, snapshot) {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          style: {
            width: "21cm",
            height: "29.7cm",
            backgroundColor: snapshot.isDraggingOver ? "blue" : "white"
          },
          className: "border p-3",
          ref: provided.innerRef
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "mb-2"
        }, "Imie i nazwisko: ................................................................."), examTasks.map(function (task, index) {
          return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_3__["Draggable"], {
            key: "task-" + task.id + "-" + index,
            draggableId: "task-" + task.id + "-" + index,
            index: index
          }, function (provided, snapshot) {
            console.log("ELO123", task.currentDataSet);
            var answers = task.currentDataSet.examAnswers.map(function (item) {
              var answerSource = item.isCorrect ? task.currentDataSet.answers[0].correctans : task.currentDataSet.answers[0].allanswers;
              return answerSource[item.index];
            });
            var ansChar = ["A", "B", "C", "D"];
            return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", _extends({
              ref: provided.innerRef
            }, provided.draggableProps, provided.dragHandleProps, {
              style: provided.draggableProps.style,
              className: "p-2",
              onClick: function onClick() {
                _this2.setTaskToEdit(index);
              } // onContextMenu={() => {
              //   this.removeTask(index);
              // }}
              ,
              onContextMenuCapture: function onContextMenuCapture() {
                _this2.removeTask(index);
              }
            }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
              className: "text-danger",
              onClick: function onClick() {
                _this2.removeTask(index);
              }
            }, "X"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", {
              className: "text-right mb-0 pb-0"
            }, ".../" + task.maxPoints + " pkt."), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("p", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
              className: "font-weight-bold"
            }, index + 1, ". "), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_latex__WEBPACK_IMPORTED_MODULE_6___default.a, null, task.text)), task.currentDataSet.image.length >= 1 && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_1__["MDBRow"], {
              center: true
            }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
              src: "http://127.0.0.1:8000/api/user/image/" + task.currentDataSet.image[0],
              style: {
                maxHeight: "100px"
              }
            }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_1__["MDBRow"], {
              between: true,
              className: "pl-2 pr-2 ml-0 mr-2"
            }, answers.map(function (item, index) {
              return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
                className: "font-weight-bold"
              }, ansChar[index] + ". "), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react_latex__WEBPACK_IMPORTED_MODULE_6___default.a, null, item));
            })));
          });
        }), provided.placeholder);
      }))));
    }
  }]);

  return ExamEditor;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]); // ExamEditor.propTypes = {};


/* harmony default export */ __webpack_exports__["default"] = (ExamEditor);

/***/ }),

/***/ "./djsr/frontend/src/components/TaskEditor.js":
/*!****************************************************!*\
  !*** ./djsr/frontend/src/components/TaskEditor.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var mdbreact__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! mdbreact */ "./node_modules/mdbreact/dist/mdbreact.esm.js");
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var _FormikMDInput__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./FormikMDInput */ "./djsr/frontend/src/components/FormikMDInput.js");
/* harmony import */ var _axiosAPI__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./axiosAPI */ "./djsr/frontend/src/components/axiosAPI.js");
function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { return function () { var Super = _getPrototypeOf(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








var TaskEditor = /*#__PURE__*/function (_Component) {
  _inherits(TaskEditor, _Component);

  var _super = _createSuper(TaskEditor);

  function TaskEditor(props) {
    var _this;

    _classCallCheck(this, TaskEditor);

    _this = _super.call(this, props);

    _defineProperty(_assertThisInitialized(_this), "setTask", function (task) {});

    _this.state = {
      task: null
    };
    return _this;
  }

  _createClass(TaskEditor, [{
    key: "render",
    // elo = () => {
    //   let task = JSON.parse(JSON.stringify(this.props.task));
    //   task.text = task.text + "1";
    //   this.props.updateTask(task);
    // };
    value: function render() {
      var _this2 = this;

      var task = this.props.task;
      console.log("TE", task);
      if (!task) return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, "Wybierz zadanie");
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_2__["MDBContainer"], null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(formik__WEBPACK_IMPORTED_MODULE_3__["Formik"], {
        enableReinitialize: true,
        initialValues: this.props.task,
        onSubmit: function onSubmit(values, helpers) {
          if (!!values.imageToUpload) {
            var formData = new FormData();
            formData.append("file", values.imageToUpload);
            _axiosAPI__WEBPACK_IMPORTED_MODULE_5__["default"].post("/user/addimage/", formData, {
              headers: {
                "Content-Type": "multipart/form-data"
              }
            }).then(function (response) {
              var task = _objectSpread({}, values);

              task.currentDataSet.image = [response.data.id];

              _this2.props.updateTask(_objectSpread({}, task));
            });
          } else _this2.props.updateTask(_objectSpread({}, values));
        }
      }, function (_ref) {
        var values = _ref.values,
            errors = _ref.errors,
            touched = _ref.touched,
            handleChange = _ref.handleChange,
            handleBlur = _ref.handleBlur,
            handleSubmit = _ref.handleSubmit,
            isSubmitting = _ref.isSubmitting,
            submitForm = _ref.submitForm,
            setFieldValue = _ref.setFieldValue;

        var handleChangeAndSubmit = function handleChangeAndSubmit(e) {
          handleChange(e);
          submitForm();
        };

        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(formik__WEBPACK_IMPORTED_MODULE_3__["Form"], null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_FormikMDInput__WEBPACK_IMPORTED_MODULE_4__["default"], {
          label: "Tre\u015B\u0107 zadania",
          errors: errors.text,
          name: "text",
          id: "text",
          touched: touched.text,
          onChange: handleChangeAndSubmit,
          onBlur: handleBlur,
          value: values.text
        }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "md-form form-group"
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
          className: "mr-3"
        }, "Liczba punkt\xF3w za zadanie"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("input", {
          type: "number",
          name: "maxPoints",
          value: values.maxPoints,
          onChange: handleChangeAndSubmit,
          onBlur: handleBlur,
          min: 1,
          max: 20
        })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "input-group"
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "input-group-prepend"
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
          className: "input-group-text",
          id: "inputGroupFileAddon01"
        }, "Obrazek do zadania")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "custom-file"
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("input", {
          type: "file",
          className: "custom-file-input",
          id: "inputGroupFile01",
          "aria-describedby": "inputGroupFileAddon01",
          onChange: function onChange(e) {
            setFieldValue("imageToUpload", e.currentTarget.files[0]);
          },
          onBlur: handleBlur
        }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("label", {
          className: "custom-file-label",
          htmlFor: "inputGroupFile01"
        }, "Wybierz"))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_2__["MDBBtn"], {
          onClick: handleSubmit
        }, "Zapisz obrazek"));
      }));
    }
  }]);

  return TaskEditor;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

TaskEditor.propTypes = {};
/* harmony default export */ __webpack_exports__["default"] = (TaskEditor);

/***/ }),

/***/ "./djsr/frontend/src/components/assets sync recursive ^\\.\\/.*$":
/*!***********************************************************!*\
  !*** ./djsr/frontend/src/components/assets sync ^\.\/.*$ ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./fonts/Roboto-Italic.ttf": "./djsr/frontend/src/components/assets/fonts/Roboto-Italic.ttf",
	"./fonts/Roboto-Medium.ttf": "./djsr/frontend/src/components/assets/fonts/Roboto-Medium.ttf",
	"./fonts/Roboto-MediumItalic.ttf": "./djsr/frontend/src/components/assets/fonts/Roboto-MediumItalic.ttf",
	"./fonts/Roboto-Regular.ttf": "./djsr/frontend/src/components/assets/fonts/Roboto-Regular.ttf",
	"./images/bee.png": "./djsr/frontend/src/components/assets/images/bee.png",
	"./jss/material-kit-react": "./djsr/frontend/src/components/assets/jss/material-kit-react.js",
	"./jss/material-kit-react.js": "./djsr/frontend/src/components/assets/jss/material-kit-react.js",
	"./jss/material-kit-react/components/badgeStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/badgeStyle.js",
	"./jss/material-kit-react/components/badgeStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/badgeStyle.js",
	"./jss/material-kit-react/components/buttonStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/buttonStyle.js",
	"./jss/material-kit-react/components/buttonStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/buttonStyle.js",
	"./jss/material-kit-react/components/cardBodyStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/cardBodyStyle.js",
	"./jss/material-kit-react/components/cardBodyStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/cardBodyStyle.js",
	"./jss/material-kit-react/components/cardFooterStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/cardFooterStyle.js",
	"./jss/material-kit-react/components/cardFooterStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/cardFooterStyle.js",
	"./jss/material-kit-react/components/cardHeaderStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/cardHeaderStyle.js",
	"./jss/material-kit-react/components/cardHeaderStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/cardHeaderStyle.js",
	"./jss/material-kit-react/components/cardStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/cardStyle.js",
	"./jss/material-kit-react/components/cardStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/cardStyle.js",
	"./jss/material-kit-react/components/customDropdownStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/customDropdownStyle.js",
	"./jss/material-kit-react/components/customDropdownStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/customDropdownStyle.js",
	"./jss/material-kit-react/components/customInputStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/customInputStyle.js",
	"./jss/material-kit-react/components/customInputStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/customInputStyle.js",
	"./jss/material-kit-react/components/customLinearProgressStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/customLinearProgressStyle.js",
	"./jss/material-kit-react/components/customLinearProgressStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/customLinearProgressStyle.js",
	"./jss/material-kit-react/components/customTabsStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/customTabsStyle.js",
	"./jss/material-kit-react/components/customTabsStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/customTabsStyle.js",
	"./jss/material-kit-react/components/footerStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/footerStyle.js",
	"./jss/material-kit-react/components/footerStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/footerStyle.js",
	"./jss/material-kit-react/components/headerLinksStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/headerLinksStyle.js",
	"./jss/material-kit-react/components/headerLinksStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/headerLinksStyle.js",
	"./jss/material-kit-react/components/headerStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/headerStyle.js",
	"./jss/material-kit-react/components/headerStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/headerStyle.js",
	"./jss/material-kit-react/components/infoStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/infoStyle.js",
	"./jss/material-kit-react/components/infoStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/infoStyle.js",
	"./jss/material-kit-react/components/navPillsStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/navPillsStyle.js",
	"./jss/material-kit-react/components/navPillsStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/navPillsStyle.js",
	"./jss/material-kit-react/components/paginationStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/paginationStyle.js",
	"./jss/material-kit-react/components/paginationStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/paginationStyle.js",
	"./jss/material-kit-react/components/parallaxStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/parallaxStyle.js",
	"./jss/material-kit-react/components/parallaxStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/parallaxStyle.js",
	"./jss/material-kit-react/components/snackbarContentStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/snackbarContentStyle.js",
	"./jss/material-kit-react/components/snackbarContentStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/snackbarContentStyle.js",
	"./jss/material-kit-react/components/typographyStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/typographyStyle.js",
	"./jss/material-kit-react/components/typographyStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/components/typographyStyle.js",
	"./jss/material-kit-react/customCheckboxRadioSwitch": "./djsr/frontend/src/components/assets/jss/material-kit-react/customCheckboxRadioSwitch.js",
	"./jss/material-kit-react/customCheckboxRadioSwitch.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/customCheckboxRadioSwitch.js",
	"./jss/material-kit-react/imagesStyles": "./djsr/frontend/src/components/assets/jss/material-kit-react/imagesStyles.js",
	"./jss/material-kit-react/imagesStyles.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/imagesStyles.js",
	"./jss/material-kit-react/modalStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/modalStyle.js",
	"./jss/material-kit-react/modalStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/modalStyle.js",
	"./jss/material-kit-react/popoverStyles": "./djsr/frontend/src/components/assets/jss/material-kit-react/popoverStyles.js",
	"./jss/material-kit-react/popoverStyles.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/popoverStyles.js",
	"./jss/material-kit-react/tooltipsStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/tooltipsStyle.js",
	"./jss/material-kit-react/tooltipsStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/tooltipsStyle.js",
	"./jss/material-kit-react/views/components": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/components.js",
	"./jss/material-kit-react/views/components.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/components.js",
	"./jss/material-kit-react/views/componentsSections/basicsStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/basicsStyle.js",
	"./jss/material-kit-react/views/componentsSections/basicsStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/basicsStyle.js",
	"./jss/material-kit-react/views/componentsSections/carouselStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/carouselStyle.js",
	"./jss/material-kit-react/views/componentsSections/carouselStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/carouselStyle.js",
	"./jss/material-kit-react/views/componentsSections/completedStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/completedStyle.js",
	"./jss/material-kit-react/views/componentsSections/completedStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/completedStyle.js",
	"./jss/material-kit-react/views/componentsSections/downloadStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/downloadStyle.js",
	"./jss/material-kit-react/views/componentsSections/downloadStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/downloadStyle.js",
	"./jss/material-kit-react/views/componentsSections/exampleStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/exampleStyle.js",
	"./jss/material-kit-react/views/componentsSections/exampleStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/exampleStyle.js",
	"./jss/material-kit-react/views/componentsSections/javascriptStyles": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/javascriptStyles.js",
	"./jss/material-kit-react/views/componentsSections/javascriptStyles.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/javascriptStyles.js",
	"./jss/material-kit-react/views/componentsSections/loginStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/loginStyle.js",
	"./jss/material-kit-react/views/componentsSections/loginStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/loginStyle.js",
	"./jss/material-kit-react/views/componentsSections/navbarsStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/navbarsStyle.js",
	"./jss/material-kit-react/views/componentsSections/navbarsStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/navbarsStyle.js",
	"./jss/material-kit-react/views/componentsSections/notificationsStyles": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/notificationsStyles.js",
	"./jss/material-kit-react/views/componentsSections/notificationsStyles.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/notificationsStyles.js",
	"./jss/material-kit-react/views/componentsSections/pillsStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/pillsStyle.js",
	"./jss/material-kit-react/views/componentsSections/pillsStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/pillsStyle.js",
	"./jss/material-kit-react/views/componentsSections/tabsStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/tabsStyle.js",
	"./jss/material-kit-react/views/componentsSections/tabsStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/tabsStyle.js",
	"./jss/material-kit-react/views/componentsSections/typographyStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/typographyStyle.js",
	"./jss/material-kit-react/views/componentsSections/typographyStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/typographyStyle.js",
	"./jss/material-kit-react/views/landingPage": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/landingPage.js",
	"./jss/material-kit-react/views/landingPage.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/landingPage.js",
	"./jss/material-kit-react/views/landingPageSections/productStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/landingPageSections/productStyle.js",
	"./jss/material-kit-react/views/landingPageSections/productStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/landingPageSections/productStyle.js",
	"./jss/material-kit-react/views/landingPageSections/teamStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/landingPageSections/teamStyle.js",
	"./jss/material-kit-react/views/landingPageSections/teamStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/landingPageSections/teamStyle.js",
	"./jss/material-kit-react/views/landingPageSections/workStyle": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/landingPageSections/workStyle.js",
	"./jss/material-kit-react/views/landingPageSections/workStyle.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/landingPageSections/workStyle.js",
	"./jss/material-kit-react/views/loginPage": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/loginPage.js",
	"./jss/material-kit-react/views/loginPage.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/loginPage.js",
	"./jss/material-kit-react/views/profilePage": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/profilePage.js",
	"./jss/material-kit-react/views/profilePage.js": "./djsr/frontend/src/components/assets/jss/material-kit-react/views/profilePage.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./djsr/frontend/src/components/assets sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./djsr/frontend/src/components/assets/fonts/Roboto-Italic.ttf":
/*!*********************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/fonts/Roboto-Italic.ttf ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "667a1fb223a7a8b2063995c08135fa2d.ttf");

/***/ }),

/***/ "./djsr/frontend/src/components/assets/fonts/Roboto-Medium.ttf":
/*!*********************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/fonts/Roboto-Medium.ttf ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "ea7d3afe129bb3e2ff353ae13db6245e.ttf");

/***/ }),

/***/ "./djsr/frontend/src/components/assets/fonts/Roboto-MediumItalic.ttf":
/*!***************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/fonts/Roboto-MediumItalic.ttf ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "9d2bc2511675cb157ba53ff5358712bf.ttf");

/***/ }),

/***/ "./djsr/frontend/src/components/assets/fonts/Roboto-Regular.ttf":
/*!**********************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/fonts/Roboto-Regular.ttf ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "71779d80f05ad6beea6ee828c0aef7d9.ttf");

/***/ }),

/***/ "./djsr/frontend/src/components/assets/images/bee.png":
/*!************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/images/bee.png ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "32f65184f3ce6a4062bad2f08cae0bdf.png");

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/components/badgeStyle.js":
/*!*********************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/components/badgeStyle.js ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");

var badgeStyle = {
  badge: {
    marginRight: "3px",
    borderRadius: "12px",
    padding: "5px 12px",
    textTransform: "uppercase",
    fontSize: "10px",
    fontWeight: "500",
    lineHeight: "1",
    color: "#fff",
    textAlign: "center",
    whiteSpace: "nowrap",
    verticalAlign: "baseline",
    display: "inline-block"
  },
  primary: {
    backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["primaryColor"]
  },
  warning: {
    backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["warningColor"]
  },
  danger: {
    backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["dangerColor"]
  },
  success: {
    backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["successColor"]
  },
  info: {
    backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["infoColor"]
  },
  rose: {
    backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["roseColor"]
  },
  gray: {
    backgroundColor: "#6c757d"
  }
};
/* harmony default export */ __webpack_exports__["default"] = (badgeStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/components/customLinearProgressStyle.js":
/*!************************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/components/customLinearProgressStyle.js ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");

var customLinearProgressStyle = {
  root: {
    height: "4px",
    marginBottom: "20px",
    overflow: "hidden"
  },
  bar: {
    height: "4px"
  },
  primary: {
    backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["primaryColor"]
  },
  warning: {
    backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["warningColor"]
  },
  danger: {
    backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["dangerColor"]
  },
  success: {
    backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["successColor"]
  },
  info: {
    backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["infoColor"]
  },
  rose: {
    backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["roseColor"]
  },
  gray: {
    backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["grayColor"]
  },
  primaryBackground: {
    background: "rgba(156, 39, 176, 0.2)"
  },
  warningBackground: {
    background: "rgba(255, 152, 0, 0.2)"
  },
  dangerBackground: {
    background: "rgba(244, 67, 54, 0.2)"
  },
  successBackground: {
    background: "rgba(76, 175, 80, 0.2)"
  },
  infoBackground: {
    background: "rgba(0, 188, 212, 0.2)"
  },
  roseBackground: {
    background: "rgba(233, 30, 99, 0.2)"
  },
  grayBackground: {
    background: "rgba(221, 221, 221, 0.2)"
  }
};
/* harmony default export */ __webpack_exports__["default"] = (customLinearProgressStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/components/customTabsStyle.js":
/*!**************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/components/customTabsStyle.js ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var customTabsStyle = {
  cardTitle: {
    "float": "left",
    padding: "10px 10px 10px 0px",
    lineHeight: "24px"
  },
  cardTitleRTL: {
    "float": "right",
    padding: "10px 0px 10px 10px !important"
  },
  displayNone: {
    display: "none !important"
  },
  tabsRoot: {
    minHeight: "unset !important"
  },
  tabRootButton: {
    minHeight: "unset !important",
    minWidth: "unset !important",
    width: "unset !important",
    height: "unset !important",
    maxWidth: "unset !important",
    maxHeight: "unset !important",
    padding: "10px 15px",
    borderRadius: "3px",
    lineHeight: "24px",
    border: "0 !important",
    color: "#fff !important",
    marginLeft: "4px",
    fontWeight: "500",
    fontSize: "12px",
    "&:last-child": {
      marginLeft: "0px"
    }
  },
  tabSelected: {
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    transition: "0.2s background-color 0.1s"
  },
  tabWrapper: {
    display: "inline-block",
    minHeight: "unset !important",
    minWidth: "unset !important",
    width: "unset !important",
    height: "unset !important",
    maxWidth: "unset !important",
    maxHeight: "unset !important",
    "& > svg": {
      verticalAlign: "middle",
      margin: "-1.55px 5px 0 0 !important"
    },
    "&,& *": {
      letterSpacing: "normal !important"
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (customTabsStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/components/infoStyle.js":
/*!********************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/components/infoStyle.js ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");

var infoStyle = {
  infoArea: {
    maxWidth: "360px",
    margin: "0 auto",
    padding: "0px"
  },
  iconWrapper: {
    "float": "left",
    marginTop: "24px",
    marginRight: "10px"
  },
  primary: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["primaryColor"]
  },
  warning: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["warningColor"]
  },
  danger: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["dangerColor"]
  },
  success: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["successColor"]
  },
  info: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["infoColor"]
  },
  rose: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["roseColor"]
  },
  gray: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["grayColor"]
  },
  icon: {
    width: "36px",
    height: "36px"
  },
  descriptionWrapper: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["grayColor"],
    overflow: "hidden"
  },
  title: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["title"],
  description: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["grayColor"],
    overflow: "hidden",
    marginTop: "0px",
    fontSize: "14px"
  },
  iconWrapperVertical: {
    "float": "none"
  },
  iconVertical: {
    width: "61px",
    height: "61px"
  }
};
/* harmony default export */ __webpack_exports__["default"] = (infoStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/components/navPillsStyle.js":
/*!************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/components/navPillsStyle.js ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



var navPillsStyle = function navPillsStyle(theme) {
  return {
    root: {
      marginTop: "20px",
      paddingLeft: "0",
      marginBottom: "0",
      overflow: "visible !important",
      lineHeight: "24px",
      textTransform: "uppercase",
      fontSize: "12px",
      fontWeight: "500",
      position: "relative",
      display: "block",
      color: "inherit"
    },
    flexContainer: _defineProperty({}, theme.breakpoints.down("xs"), {
      display: "flex",
      flexWrap: "wrap"
    }),
    displayNone: {
      display: "none !important"
    },
    fixed: {
      overflow: "visible !important"
    },
    horizontalDisplay: {
      display: "block"
    },
    pills: {
      "float": "left",
      position: "relative",
      display: "block",
      borderRadius: "30px",
      minWidth: "100px",
      textAlign: "center",
      transition: "all .3s",
      padding: "10px 15px",
      color: "#555555",
      height: "auto",
      opacity: "1",
      maxWidth: "100%",
      margin: "0 5px"
    },
    pillsWithIcons: {
      borderRadius: "4px"
    },
    tabIcon: {
      width: "30px",
      height: "30px",
      display: "block",
      margin: "15px 0 !important",
      "&, & *": {
        letterSpacing: "normal !important"
      }
    },
    horizontalPills: {
      width: "100%",
      "float": "none !important",
      "& + button": {
        margin: "10px 0"
      }
    },
    contentWrapper: {
      marginTop: "20px"
    },
    primary: {
      "&,&:hover": {
        color: "#FFFFFF",
        backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["primaryColor"],
        boxShadow: "0 4px 20px 0px rgba(0, 0, 0, 0.14), 0 7px 10px -5px rgba(156, 39, 176, 0.4)"
      }
    },
    info: {
      "&,&:hover": {
        color: "#FFFFFF",
        backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["infoColor"],
        boxShadow: "0 4px 20px 0px rgba(0, 0, 0, 0.14), 0 7px 10px -5px rgba(76, 175, 80, 0.4)"
      }
    },
    success: {
      "&,&:hover": {
        color: "#FFFFFF",
        backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["successColor"],
        boxShadow: "0 2px 2px 0 rgba(76, 175, 80, 0.14), 0 3px 1px -2px rgba(76, 175, 80, 0.2), 0 1px 5px 0 rgba(76, 175, 80, 0.12)"
      }
    },
    warning: {
      "&,&:hover": {
        color: "#FFFFFF",
        backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["warningColor"],
        boxShadow: "0 4px 20px 0px rgba(0, 0, 0, 0.14), 0 7px 10px -5px rgba(255, 152, 0, 0.4)"
      }
    },
    danger: {
      "&,&:hover": {
        color: "#FFFFFF",
        backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["dangerColor"],
        boxShadow: "0 4px 20px 0px rgba(0, 0, 0, 0.14), 0 7px 10px -5px rgba(255, 152, 0, 0.4)"
      }
    },
    rose: {
      "&,&:hover": {
        color: "#FFFFFF",
        backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["roseColor"],
        boxShadow: "0 4px 20px 0px rgba(0, 0, 0, 0.14), 0 7px 10px -5px rgba(233, 30, 99, 0.4)"
      }
    },
    alignCenter: {
      alignItems: "center",
      justifyContent: "center"
    },
    tabWrapper: {
      color: "inherit",
      position: "relative",
      fontSize: "12px",
      lineHeight: "24px",
      fontWeight: "500",
      textTransform: "uppercase",
      "&,& *": {
        letterSpacing: "normal"
      }
    }
  };
};

/* harmony default export */ __webpack_exports__["default"] = (navPillsStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/components/paginationStyle.js":
/*!**************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/components/paginationStyle.js ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");

var paginationStyle = {
  pagination: {
    display: "inline-block",
    paddingLeft: "0",
    margin: "0 0 20px 0",
    borderRadius: "4px"
  },
  paginationItem: {
    display: "inline"
  },
  paginationLink: {
    ":first-of-type": {
      marginleft: "0"
    },
    letterSpacing: "unset",
    border: "0",
    borderRadius: "30px !important",
    transition: "all .3s",
    padding: "0px 11px",
    margin: "0 3px",
    minWidth: "30px",
    height: "30px",
    minHeight: "auto",
    lineHeight: "30px",
    fontWeight: "400",
    fontSize: "12px",
    textTransform: "uppercase",
    background: "transparent",
    position: "relative",
    "float": "left",
    textDecoration: "none",
    boxSizing: "border-box",
    "&,&:hover,&:focus": {
      color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["grayColor"]
    },
    "&:hover,&:focus": {
      zIndex: "3",
      backgroundColor: "#eee",
      borderColor: "#ddd"
    },
    "&:hover": {
      cursor: "pointer"
    }
  },
  primary: {
    "&,&:hover,&:focus": {
      backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["primaryColor"],
      borderColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["primaryColor"],
      color: "#FFFFFF",
      boxShadow: "0 4px 5px 0 rgba(156, 39, 176, 0.14), 0 1px 10px 0 rgba(156, 39, 176, 0.12), 0 2px 4px -1px rgba(156, 39, 176, 0.2)"
    },
    "&:hover,&:focus": {
      zIndex: "2",
      cursor: "default"
    }
  },
  info: {
    "&,&:hover,&:focus": {
      backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["infoColor"],
      borderColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["infoColor"],
      color: "#FFFFFF",
      boxShadow: "0 4px 5px 0 rgba(0, 188, 212, 0.14), 0 1px 10px 0 rgba(0, 188, 212, 0.12), 0 2px 4px -1px rgba(0, 188, 212, 0.2)"
    },
    "&:hover,&:focus": {
      zIndex: "2",
      cursor: "default"
    }
  },
  success: {
    "&,&:hover,&:focus": {
      backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["successColor"],
      borderColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["successColor"],
      color: "#FFFFFF",
      boxShadow: "0 4px 5px 0 rgba(76, 175, 80, 0.14), 0 1px 10px 0 rgba(76, 175, 80, 0.12), 0 2px 4px -1px rgba(76, 175, 80, 0.2)"
    },
    "&:hover,&:focus": {
      zIndex: "2",
      cursor: "default"
    }
  },
  warning: {
    "&,&:hover,&:focus": {
      backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["warningColor"],
      borderColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["warningColor"],
      color: "#FFFFFF",
      boxShadow: "0 4px 5px 0 rgba(255, 152, 0, 0.14), 0 1px 10px 0 rgba(255, 152, 0, 0.12), 0 2px 4px -1px rgba(255, 152, 0, 0.2)"
    },
    "&:hover,&:focus": {
      zIndex: "2",
      cursor: "default"
    }
  },
  danger: {
    "&,&:hover,&:focus": {
      backgroundColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["dangerColor"],
      borderColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["dangerColor"],
      color: "#FFFFFF",
      boxShadow: "0 4px 5px 0 rgba(244, 67, 54, 0.14), 0 1px 10px 0 rgba(244, 67, 54, 0.12), 0 2px 4px -1px rgba(244, 67, 54, 0.2)"
    },
    "&:hover,&:focus": {
      zIndex: "2",
      cursor: "default"
    }
  },
  disabled: {
    "&,&:hover,&:focus": {
      color: "#777",
      cursor: "not-allowed",
      backgroundColor: "#fff",
      borderColor: "#ddd"
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (paginationStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/components/parallaxStyle.js":
/*!************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/components/parallaxStyle.js ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var parallaxStyle = {
  parallax: {
    height: "90vh",
    maxHeight: "1000px",
    overflow: "hidden",
    position: "relative",
    backgroundPosition: "center center",
    backgroundSize: "cover",
    margin: "0",
    padding: "0",
    border: "0",
    display: "flex",
    alignItems: "center"
  },
  filter: {
    "&:before": {
      background: "rgba(0, 0, 0, 0.5)"
    },
    "&:after,&:before": {
      position: "absolute",
      zIndex: "1",
      width: "100%",
      height: "100%",
      display: "block",
      left: "0",
      top: "0",
      content: "''"
    }
  },
  small: {
    height: "380px"
  }
};
/* harmony default export */ __webpack_exports__["default"] = (parallaxStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/components/snackbarContentStyle.js":
/*!*******************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/components/snackbarContentStyle.js ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


var snackbarContentStyle = {
  root: _objectSpread({}, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["defaultFont"], {
    position: "relative",
    padding: "20px 15px",
    lineHeight: "20px",
    marginBottom: "20px",
    fontSize: "14px",
    backgroundColor: "white",
    color: "#555555",
    borderRadius: "0px",
    maxWidth: "100%",
    minWidth: "auto",
    boxShadow: "0 12px 20px -10px rgba(255, 255, 255, 0.28), 0 4px 20px 0px rgba(0, 0, 0, 0.12), 0 7px 8px -5px rgba(255, 255, 255, 0.2)"
  }),
  info: _objectSpread({
    backgroundColor: "#00d3ee",
    color: "#ffffff"
  }, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["infoBoxShadow"]),
  success: _objectSpread({
    backgroundColor: "#5cb860",
    color: "#ffffff"
  }, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["successBoxShadow"]),
  warning: _objectSpread({
    backgroundColor: "#ffa21a",
    color: "#ffffff"
  }, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["warningBoxShadow"]),
  danger: _objectSpread({
    backgroundColor: "#f55a4e",
    color: "#ffffff"
  }, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["dangerBoxShadow"]),
  primary: _objectSpread({
    backgroundColor: "#af2cc5",
    color: "#ffffff"
  }, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["primaryBoxShadow"]),
  message: {
    padding: "0",
    display: "block",
    maxWidth: "89%",
    "&,& *": {
      letterSpacing: "normal"
    }
  },
  close: {
    width: "14px",
    height: "14px"
  },
  iconButton: {
    width: "24px",
    height: "24px",
    "float": "right",
    fontSize: "1.5rem",
    fontWeight: "500",
    lineHeight: "1",
    position: "absolute",
    right: "-4px",
    top: "0",
    padding: "0"
  },
  icon: {
    display: "block",
    "float": "left",
    marginRight: "1.071rem"
  },
  container: _objectSpread({}, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["container"], {
    position: "relative"
  })
};
/* harmony default export */ __webpack_exports__["default"] = (snackbarContentStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/components/typographyStyle.js":
/*!**************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/components/typographyStyle.js ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


var typographyStyle = {
  defaultFontStyle: _objectSpread({}, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["defaultFont"], {
    fontSize: "14px"
  }),
  defaultHeaderMargins: {
    marginTop: "20px",
    marginBottom: "10px"
  },
  quote: {
    padding: "10px 20px",
    margin: "0 0 20px",
    fontSize: "17.5px",
    borderLeft: "5px solid #eee"
  },
  quoteText: {
    margin: "0 0 10px",
    fontStyle: "italic"
  },
  quoteAuthor: {
    display: "block",
    fontSize: "80%",
    lineHeight: "1.42857143",
    color: "#777"
  },
  mutedText: {
    color: "#777"
  },
  primaryText: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["primaryColor"]
  },
  infoText: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["infoColor"]
  },
  successText: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["successColor"]
  },
  warningText: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["warningColor"]
  },
  dangerText: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["dangerColor"]
  },
  smallText: {
    fontSize: "65%",
    fontWeight: "400",
    lineHeight: "1",
    color: "#777"
  }
};
/* harmony default export */ __webpack_exports__["default"] = (typographyStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/customCheckboxRadioSwitch.js":
/*!*************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/customCheckboxRadioSwitch.js ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");

var customCheckboxRadioSwitch = {
  checkRoot: {
    padding: "12px",
    "&:hover": {
      backgroundColor: "unset"
    }
  },
  radioRoot: {
    padding: "12px",
    "&:hover": {
      backgroundColor: "unset"
    }
  },
  labelRoot: {
    marginLeft: "-14px"
  },
  checkboxAndRadio: {
    position: "relative",
    display: "block",
    marginTop: "10px",
    marginBottom: "10px"
  },
  checkboxAndRadioHorizontal: {
    position: "relative",
    display: "block",
    "&:first-child": {
      marginTop: "10px"
    },
    "&:not(:first-child)": {
      marginTop: "-14px"
    },
    marginTop: "0",
    marginBottom: "0"
  },
  checked: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["primaryColor"] + "!important"
  },
  checkedIcon: {
    width: "20px",
    height: "20px",
    border: "1px solid rgba(0, 0, 0, .54)",
    borderRadius: "3px"
  },
  uncheckedIcon: {
    width: "0px",
    height: "0px",
    padding: "9px",
    border: "1px solid rgba(0, 0, 0, .54)",
    borderRadius: "3px"
  },
  disabledCheckboxAndRadio: {
    opacity: "0.45"
  },
  label: {
    cursor: "pointer",
    paddingLeft: "0",
    color: "rgba(0, 0, 0, 0.26)",
    fontSize: "14px",
    lineHeight: "1.428571429",
    fontWeight: "400",
    display: "inline-flex",
    transition: "0.3s ease all",
    letterSpacing: "unset"
  },
  labelHorizontal: {
    color: "rgba(0, 0, 0, 0.26)",
    cursor: "pointer",
    display: "inline-flex",
    fontSize: "14px",
    lineHeight: "1.428571429",
    fontWeight: "400",
    paddingTop: "39px",
    marginRight: "0",
    "@media (min-width: 992px)": {
      "float": "right"
    }
  },
  labelHorizontalRadioCheckbox: {
    paddingTop: "22px"
  },
  labelLeftHorizontal: {
    color: "rgba(0, 0, 0, 0.26)",
    cursor: "pointer",
    display: "inline-flex",
    fontSize: "14px",
    lineHeight: "1.428571429",
    fontWeight: "400",
    paddingTop: "22px",
    marginRight: "0"
  },
  labelError: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["dangerColor"]
  },
  radio: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["primaryColor"] + "!important"
  },
  radioChecked: {
    width: "16px",
    height: "16px",
    border: "1px solid " + _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["primaryColor"],
    borderRadius: "50%"
  },
  radioUnchecked: {
    width: "0px",
    height: "0px",
    padding: "7px",
    border: "1px solid rgba(0, 0, 0, .54)",
    borderRadius: "50%"
  },
  inlineChecks: {
    marginTop: "8px"
  },
  iconCheckbox: {
    height: "116px",
    width: "116px",
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["grayColor"],
    "& > span:first-child": {
      borderWidth: "4px",
      borderStyle: "solid",
      borderColor: "#CCCCCC",
      textAlign: "center",
      verticalAlign: "middle",
      borderRadius: "50%",
      color: "inherit",
      margin: "0 auto 20px",
      transition: "all 0.2s"
    },
    "&:hover": {
      color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["roseColor"],
      "& > span:first-child": {
        borderColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["roseColor"]
      }
    }
  },
  iconCheckboxChecked: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["roseColor"],
    "& > span:first-child": {
      borderColor: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["roseColor"]
    }
  },
  iconCheckboxIcon: {
    fontSize: "40px",
    lineHeight: "111px"
  },
  switchBase: {
    color: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["primaryColor"] + "!important"
  },
  switchIcon: {
    boxShadow: "0 1px 3px 1px rgba(0, 0, 0, 0.4)",
    color: "#FFFFFF !important",
    border: "1px solid rgba(0, 0, 0, .54)"
  },
  switchBar: {
    width: "30px",
    height: "15px",
    backgroundColor: "rgb(80, 80, 80)",
    borderRadius: "15px",
    opacity: "0.7!important"
  },
  switchChecked: {
    "& + $switchBar": {
      backgroundColor: "rgba(156, 39, 176, 1) !important"
    },
    "& $switchIcon": {
      borderColor: "#9c27b0"
    }
  },
  switchRoot: {
    height: "48px"
  }
};
/* harmony default export */ __webpack_exports__["default"] = (customCheckboxRadioSwitch);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/imagesStyles.js":
/*!************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/imagesStyles.js ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var imagesStyles = {
  imgFluid: {
    maxWidth: "100%",
    height: "auto"
  },
  imgRounded: {
    borderRadius: "6px !important"
  },
  imgRoundedCircle: {
    borderRadius: "50% !important"
  },
  imgRaised: {
    boxShadow: "0 5px 15px -8px rgba(0, 0, 0, 0.24), 0 8px 10px -5px rgba(0, 0, 0, 0.2)"
  },
  imgGallery: {
    width: "100%",
    marginBottom: "2.142rem"
  },
  imgCardTop: {
    width: "100%",
    borderTopLeftRadius: "calc(.25rem - 1px)",
    borderTopRightRadius: "calc(.25rem - 1px)"
  },
  imgCardBottom: {
    width: "100%",
    borderBottomLeftRadius: "calc(.25rem - 1px)",
    borderBottomRightRadius: "calc(.25rem - 1px)"
  },
  imgCard: {
    width: "100%",
    borderRadius: "calc(.25rem - 1px)"
  },
  imgCardOverlay: {
    position: "absolute",
    top: "0",
    right: "0",
    bottom: "0",
    left: "0",
    padding: "1.25rem"
  }
};
/* harmony default export */ __webpack_exports__["default"] = (imagesStyles);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/modalStyle.js":
/*!**********************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/modalStyle.js ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var modalStyle = {
  modal: {
    borderRadius: "6px"
  },
  modalHeader: {
    borderBottom: "none",
    paddingTop: "24px",
    paddingRight: "24px",
    paddingBottom: "0",
    paddingLeft: "24px",
    minHeight: "16.43px"
  },
  modalTitle: {
    margin: "0",
    lineHeight: "1.42857143"
  },
  modalCloseButton: {
    color: "#999999",
    marginTop: "-12px",
    WebkitAppearance: "none",
    padding: "0",
    cursor: "pointer",
    background: "0 0",
    border: "0",
    fontSize: "inherit",
    opacity: ".9",
    textShadow: "none",
    fontWeight: "700",
    lineHeight: "1",
    "float": "right"
  },
  modalClose: {
    width: "16px",
    height: "16px"
  },
  modalBody: {
    paddingTop: "24px",
    paddingRight: "24px",
    paddingBottom: "16px",
    paddingLeft: "24px",
    position: "relative"
  },
  modalFooter: {
    padding: "15px",
    textAlign: "right",
    paddingTop: "0",
    margin: "0"
  },
  modalFooterCenter: {
    marginLeft: "auto",
    marginRight: "auto"
  }
};
/* harmony default export */ __webpack_exports__["default"] = (modalStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/popoverStyles.js":
/*!*************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/popoverStyles.js ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var popoverStyles = {
  popover: {
    padding: "0",
    boxShadow: "0 16px 24px 2px rgba(0, 0, 0, 0.14), 0 6px 30px 5px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.2)",
    lineHeight: "1.5em",
    background: "#fff",
    border: "none",
    borderRadius: "3px",
    display: "block",
    maxWidth: "276px",
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    fontStyle: "normal",
    fontWeight: "400",
    textAlign: "start",
    textDecoration: "none",
    textShadow: "none",
    textTransform: "none",
    letterSpacing: "normal",
    wordBreak: "normal",
    wordSpacing: "normal",
    whiteSpace: "normal",
    lineBreak: "auto",
    fontSize: "0.875rem",
    wordWrap: "break-word"
  },
  popoverBottom: {
    marginTop: "5px"
  },
  popoverHeader: {
    backgroundColor: "#fff",
    border: "none",
    padding: "15px 15px 5px",
    fontSize: "1.125rem",
    margin: "0",
    color: "#555",
    borderTopLeftRadius: "calc(0.3rem - 1px)",
    borderTopRightRadius: "calc(0.3rem - 1px)"
  },
  popoverBody: {
    padding: "10px 15px 15px",
    lineHeight: "1.4",
    color: "#555"
  }
};
/* harmony default export */ __webpack_exports__["default"] = (popoverStyles);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/components.js":
/*!****************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/components.js ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");

var componentsStyle = {
  container: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["container"],
  brand: {
    color: "#FFFFFF",
    textAlign: "left"
  },
  title: {
    fontSize: "4.2rem",
    fontWeight: "600",
    display: "inline-block",
    position: "relative"
  },
  subtitle: {
    fontSize: "1.313rem",
    maxWidth: "500px",
    margin: "10px 0 0"
  },
  main: {
    background: "#FFFFFF",
    position: "relative",
    zIndex: "3"
  },
  mainRaised: {
    margin: "-60px 30px 0px",
    borderRadius: "6px",
    boxShadow: "0 16px 24px 2px rgba(0, 0, 0, 0.14), 0 6px 30px 5px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.2)"
  },
  link: {
    textDecoration: "none"
  },
  textCenter: {
    textAlign: "center"
  }
};
/* harmony default export */ __webpack_exports__["default"] = (componentsStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/basicsStyle.js":
/*!************************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/basicsStyle.js ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");
/* harmony import */ var _jss_material_kit_react_customCheckboxRadioSwitch_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../jss/material-kit-react/customCheckboxRadioSwitch.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react/customCheckboxRadioSwitch.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




var basicsStyle = _objectSpread({
  sections: {
    padding: "70px 0"
  },
  container: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["container"],
  title: _objectSpread({}, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["title"], {
    marginTop: "30px",
    minHeight: "32px",
    textDecoration: "none"
  }),
  space50: {
    height: "50px",
    display: "block"
  },
  space70: {
    height: "70px",
    display: "block"
  },
  icons: {
    width: "17px",
    height: "17px",
    color: "#FFFFFF"
  }
}, _jss_material_kit_react_customCheckboxRadioSwitch_js__WEBPACK_IMPORTED_MODULE_1__["default"]);

/* harmony default export */ __webpack_exports__["default"] = (basicsStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/carouselStyle.js":
/*!**************************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/carouselStyle.js ***!
  \**************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");

var carouselStyle = {
  section: {
    padding: "70px 0"
  },
  container: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["container"],
  marginAuto: {
    marginLeft: "auto !important",
    marginRight: "auto !important"
  }
};
/* harmony default export */ __webpack_exports__["default"] = (carouselStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/completedStyle.js":
/*!***************************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/completedStyle.js ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../jss/material-kit-react */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


var completedStyle = {
  section: {
    padding: "70px 0"
  },
  container: _objectSpread({}, _jss_material_kit_react__WEBPACK_IMPORTED_MODULE_0__["container"], {
    textAlign: "center !important"
  })
};
/* harmony default export */ __webpack_exports__["default"] = (completedStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/downloadStyle.js":
/*!**************************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/downloadStyle.js ***!
  \**************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");

var downloadStyle = {
  section: {
    padding: "70px 0"
  },
  container: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["container"],
  textCenter: {
    textAlign: "center"
  },
  sharingArea: {
    marginTop: "80px"
  },
  socials: {
    maxWidth: "24px",
    marginTop: "0",
    width: "100%",
    transform: "none",
    left: "0",
    top: "0",
    height: "100%",
    fontSize: "20px",
    marginRight: "4px"
  }
};
/* harmony default export */ __webpack_exports__["default"] = (downloadStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/exampleStyle.js":
/*!*************************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/exampleStyle.js ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");
/* harmony import */ var _jss_material_kit_react_imagesStyles_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../jss/material-kit-react/imagesStyles.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react/imagesStyles.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




var exampleStyle = _objectSpread({
  section: {
    padding: "70px 0"
  },
  container: _objectSpread({}, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["containerFluid"], {
    textAlign: "center !important"
  })
}, _jss_material_kit_react_imagesStyles_js__WEBPACK_IMPORTED_MODULE_1__["default"], {
  link: {
    textDecoration: "none"
  }
});

/* harmony default export */ __webpack_exports__["default"] = (exampleStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/javascriptStyles.js":
/*!*****************************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/javascriptStyles.js ***!
  \*****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");
/* harmony import */ var _jss_material_kit_react_modalStyle_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../jss/material-kit-react/modalStyle.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react/modalStyle.js");
/* harmony import */ var _jss_material_kit_react_tooltipsStyle_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../jss/material-kit-react/tooltipsStyle.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react/tooltipsStyle.js");
/* harmony import */ var _jss_material_kit_react_popoverStyles_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../jss/material-kit-react/popoverStyles.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react/popoverStyles.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






var javascriptStyles = _objectSpread({
  section: {
    padding: "70px 0 0"
  },
  container: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["container"],
  title: _objectSpread({}, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["title"], {
    marginTop: "30px",
    minHeight: "32px",
    textDecoration: "none"
  }),
  icon: {
    width: "17px",
    height: "17px",
    marginRight: "4px"
  }
}, _jss_material_kit_react_modalStyle_js__WEBPACK_IMPORTED_MODULE_1__["default"], {
  label: {
    color: "rgba(0, 0, 0, 0.26)",
    cursor: "pointer",
    display: "inline-flex",
    fontSize: "14px",
    transition: "0.3s ease all",
    lineHeight: "1.428571429",
    fontWeight: "400",
    paddingLeft: "0",
    letterSpacing: "normal"
  }
}, _jss_material_kit_react_tooltipsStyle_js__WEBPACK_IMPORTED_MODULE_2__["default"], {}, _jss_material_kit_react_popoverStyles_js__WEBPACK_IMPORTED_MODULE_3__["default"]);

/* harmony default export */ __webpack_exports__["default"] = (javascriptStyles);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/loginStyle.js":
/*!***********************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/loginStyle.js ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");
/* harmony import */ var _images_bee_png__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../images/bee.png */ "./djsr/frontend/src/components/assets/images/bee.png");


var loginStyle = {
  section: {
    minHeight: "110vh",
    maxHeight: "1600px",
    overflow: "hidden",
    padding: "70px 0",
    backgroundPosition: "top center",
    backgroundSize: "cover",
    margin: "0",
    border: "0",
    display: "flex",
    alignItems: "center",
    backgroundImage: "url(" + _images_bee_png__WEBPACK_IMPORTED_MODULE_1__["default"] + ")"
  },
  container: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["container"],
  form: {
    margin: "0"
  },
  cardHeader: {
    width: "auto",
    textAlign: "center",
    marginLeft: "20px",
    marginRight: "20px",
    marginTop: "-40px",
    padding: "20px 0",
    marginBottom: "15px"
  },
  socialIcons: {
    maxWidth: "24px",
    marginTop: "0",
    width: "100%",
    transform: "none",
    left: "0",
    top: "0",
    height: "100%",
    lineHeight: "41px",
    fontSize: "20px"
  },
  divider: {
    marginTop: "30px",
    marginBottom: "0px",
    textAlign: "center"
  },
  cardFooter: {
    paddingTop: "0rem",
    border: "0",
    borderRadius: "6px",
    justifyContent: "center !important"
  },
  socialLine: {
    marginTop: "1rem",
    textAlign: "center",
    padding: "0"
  },
  inputIconsColor: {
    color: "#495057"
  }
};
/* harmony default export */ __webpack_exports__["default"] = (loginStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/navbarsStyle.js":
/*!*************************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/navbarsStyle.js ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");
/* harmony import */ var _jss_material_kit_react_components_headerLinksStyle_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../jss/material-kit-react/components/headerLinksStyle.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react/components/headerLinksStyle.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




var navbarsStyle = function navbarsStyle(theme) {
  return _objectSpread({
    section: {
      padding: "70px 0",
      paddingTop: "0"
    },
    container: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["container"],
    title: _objectSpread({}, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["title"], {
      marginTop: "30px",
      minHeight: "32px",
      textDecoration: "none"
    }),
    navbar: {
      marginBottom: "-20px",
      zIndex: "100",
      position: "relative",
      overflow: "hidden",
      "& header": {
        borderRadius: "0"
      }
    },
    navigation: {
      backgroundPosition: "center center",
      backgroundSize: "cover",
      marginTop: "0",
      minHeight: "740px"
    },
    formControl: {
      margin: "0 !important",
      paddingTop: "0"
    },
    inputRootCustomClasses: {
      margin: "0!important"
    },
    searchIcon: {
      width: "20px",
      height: "20px",
      color: "inherit"
    }
  }, Object(_jss_material_kit_react_components_headerLinksStyle_js__WEBPACK_IMPORTED_MODULE_1__["default"])(theme), {
    img: {
      width: "40px",
      height: "40px",
      borderRadius: "50%"
    },
    imageDropdownButton: {
      padding: "0px",
      top: "4px",
      borderRadius: "50%",
      marginLeft: "5px"
    }
  });
};

/* harmony default export */ __webpack_exports__["default"] = (navbarsStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/notificationsStyles.js":
/*!********************************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/notificationsStyles.js ***!
  \********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


var notificationsStyles = {
  section: {
    backgroundColor: "#FFFFFF",
    display: "block",
    width: "100%",
    position: "relative",
    padding: "0"
  },
  title: _objectSpread({}, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["title"], {
    marginTop: "30px",
    minHeight: "32px",
    textDecoration: "none"
  }),
  container: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["container"]
};
/* harmony default export */ __webpack_exports__["default"] = (notificationsStyles);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/pillsStyle.js":
/*!***********************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/pillsStyle.js ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


var pillsStyle = {
  section: {
    padding: "70px 0"
  },
  container: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["container"],
  title: _objectSpread({}, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["title"], {
    marginTop: "30px",
    minHeight: "32px",
    textDecoration: "none"
  })
};
/* harmony default export */ __webpack_exports__["default"] = (pillsStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/tabsStyle.js":
/*!**********************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/tabsStyle.js ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");

var tabsStyle = {
  section: {
    background: "#EEEEEE",
    padding: "70px 0"
  },
  container: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["container"],
  textCenter: {
    textAlign: "center"
  }
};
/* harmony default export */ __webpack_exports__["default"] = (tabsStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/typographyStyle.js":
/*!****************************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/componentsSections/typographyStyle.js ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");
/* harmony import */ var _jss_material_kit_react_imagesStyles_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../jss/material-kit-react/imagesStyles.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react/imagesStyles.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




var typographyStyle = _objectSpread({
  section: {
    padding: "70px 0"
  },
  container: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["container"],
  space50: {
    height: "50px",
    display: "block"
  },
  title: _objectSpread({}, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["title"], {
    marginTop: "30px",
    minHeight: "32px",
    textDecoration: "none"
  }),
  typo: {
    paddingLeft: "25%",
    marginBottom: "40px",
    position: "relative",
    width: "100%"
  },
  note: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    bottom: "10px",
    color: "#c0c1c2",
    display: "block",
    fontWeight: "400",
    fontSize: "13px",
    lineHeight: "13px",
    left: "0",
    marginLeft: "20px",
    position: "absolute",
    width: "260px"
  },
  marginLeft: {
    marginLeft: "auto !important"
  }
}, _jss_material_kit_react_imagesStyles_js__WEBPACK_IMPORTED_MODULE_1__["default"]);

/* harmony default export */ __webpack_exports__["default"] = (typographyStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/landingPage.js":
/*!*****************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/landingPage.js ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


var landingPageStyle = {
  container: _objectSpread({
    zIndex: "12",
    color: "#FFFFFF"
  }, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["container"]),
  title: _objectSpread({}, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["title"], {
    display: "inline-block",
    position: "relative",
    marginTop: "30px",
    minHeight: "32px",
    color: "#FFFFFF",
    textDecoration: "none"
  }),
  subtitle: {
    fontSize: "1.313rem",
    maxWidth: "500px",
    margin: "10px auto 0"
  },
  main: {
    background: "#FFFFFF",
    position: "relative",
    zIndex: "3"
  },
  mainRaised: {
    margin: "-60px 30px 0px",
    borderRadius: "6px",
    boxShadow: "0 16px 24px 2px rgba(0, 0, 0, 0.14), 0 6px 30px 5px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.2)"
  }
};
/* harmony default export */ __webpack_exports__["default"] = (landingPageStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/landingPageSections/productStyle.js":
/*!**************************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/landingPageSections/productStyle.js ***!
  \**************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


var productStyle = {
  section: {
    padding: "70px 0",
    textAlign: "center"
  },
  title: _objectSpread({}, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["title"], {
    marginBottom: "1rem",
    marginTop: "30px",
    minHeight: "32px",
    textDecoration: "none"
  }),
  description: {
    color: "#999"
  }
};
/* harmony default export */ __webpack_exports__["default"] = (productStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/landingPageSections/teamStyle.js":
/*!***********************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/landingPageSections/teamStyle.js ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");
/* harmony import */ var _jss_material_kit_react_imagesStyles_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../jss/material-kit-react/imagesStyles.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react/imagesStyles.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




var teamStyle = _objectSpread({
  section: {
    padding: "70px 0",
    textAlign: "center"
  },
  title: _objectSpread({}, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["title"], {
    marginBottom: "1rem",
    marginTop: "30px",
    minHeight: "32px",
    textDecoration: "none"
  })
}, _jss_material_kit_react_imagesStyles_js__WEBPACK_IMPORTED_MODULE_1__["default"], {
  itemGrid: {
    marginLeft: "auto",
    marginRight: "auto"
  },
  cardTitle: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["cardTitle"],
  smallTitle: {
    color: "#6c757d"
  },
  description: {
    color: "#999"
  },
  justifyCenter: {
    justifyContent: "center !important"
  },
  socials: {
    marginTop: "0",
    width: "100%",
    transform: "none",
    left: "0",
    top: "0",
    height: "100%",
    lineHeight: "41px",
    fontSize: "20px",
    color: "#999"
  },
  margin5: {
    margin: "5px"
  }
});

/* harmony default export */ __webpack_exports__["default"] = (teamStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/landingPageSections/workStyle.js":
/*!***********************************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/landingPageSections/workStyle.js ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


var workStyle = {
  section: {
    padding: "70px 0"
  },
  title: _objectSpread({}, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["title"], {
    marginBottom: "50px",
    marginTop: "30px",
    minHeight: "32px",
    textDecoration: "none",
    textAlign: "center"
  }),
  description: {
    color: "#999",
    textAlign: "center"
  },
  textCenter: {
    textAlign: "center"
  },
  textArea: {
    marginRight: "15px",
    marginLeft: "15px"
  }
};
/* harmony default export */ __webpack_exports__["default"] = (workStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/assets/jss/material-kit-react/views/profilePage.js":
/*!*****************************************************************************************!*\
  !*** ./djsr/frontend/src/components/assets/jss/material-kit-react/views/profilePage.js ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../jss/material-kit-react.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react.js");
/* harmony import */ var _jss_material_kit_react_imagesStyles_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../jss/material-kit-react/imagesStyles.js */ "./djsr/frontend/src/components/assets/jss/material-kit-react/imagesStyles.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




var profilePageStyle = _objectSpread({
  container: _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["container"],
  profile: {
    textAlign: "center",
    "& img": {
      maxWidth: "160px",
      width: "100%",
      margin: "0 auto",
      transform: "translate3d(0, -50%, 0)"
    }
  },
  description: {
    margin: "1.071rem auto 0",
    maxWidth: "600px",
    color: "#999",
    textAlign: "center !important"
  },
  name: {
    marginTop: "-80px"
  }
}, _jss_material_kit_react_imagesStyles_js__WEBPACK_IMPORTED_MODULE_1__["default"], {
  main: {
    background: "#FFFFFF",
    position: "relative",
    zIndex: "3"
  },
  mainRaised: {
    margin: "-60px 30px 0px",
    borderRadius: "6px",
    boxShadow: "0 16px 24px 2px rgba(0, 0, 0, 0.14), 0 6px 30px 5px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.2)"
  },
  title: _objectSpread({}, _jss_material_kit_react_js__WEBPACK_IMPORTED_MODULE_0__["title"], {
    display: "inline-block",
    position: "relative",
    marginTop: "30px",
    minHeight: "32px",
    textDecoration: "none"
  }),
  socials: {
    marginTop: "0",
    width: "100%",
    transform: "none",
    left: "0",
    top: "0",
    height: "100%",
    lineHeight: "41px",
    fontSize: "20px",
    color: "#999"
  },
  navWrapper: {
    margin: "20px auto 50px auto",
    textAlign: "center"
  }
});

/* harmony default export */ __webpack_exports__["default"] = (profilePageStyle);

/***/ }),

/***/ "./djsr/frontend/src/components/registered-files.js":
/*!**********************************************************!*\
  !*** ./djsr/frontend/src/components/registered-files.js ***!
  \**********************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! fs */ "./node_modules/pdfkit/js/virtual-fs.js");
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var pdfkit_js_data_Courier_Bold_afm__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! pdfkit/js/data/Courier-Bold.afm */ "./node_modules/pdfkit/js/data/Courier-Bold.afm");
 // use raw-loader explicitly
// import Courier from '!!raw-loader!pdfkit/js/data/Courier.afm'
// use raw-loader implicitly (webpack is configured to load *.afm files using raw loader)



function registerBinaryFiles(ctx) {
  ctx.keys().forEach(function (key) {
    // extracts "./" from beginning of the key
    fs__WEBPACK_IMPORTED_MODULE_0___default.a.writeFileSync(key.substring(2), ctx(key));
  });
}

function registerAFMFonts(ctx) {
  ctx.keys().forEach(function (key) {
    var match = key.match(/([^/]*\.afm$)/);

    if (match) {
      // afm files must be stored on data path
      fs__WEBPACK_IMPORTED_MODULE_0___default.a.writeFileSync("data/".concat(match[0]), ctx(key)["default"]);
    }
  });
} // register all files found in assets folder (relative to src)


registerBinaryFiles(__webpack_require__("./djsr/frontend/src/components/assets sync recursive ^\\.\\/.*$")); // register AFM fonts distributed with pdfkit
// is good practice to register only required fonts to avoid the bundle size increase

registerAFMFonts(__webpack_require__("./node_modules/pdfkit/js/data sync Helvetica.*\\.afm$")); // register files imported directly
// fs.writeFileSync('data/Courier.afm', Courier)

fs__WEBPACK_IMPORTED_MODULE_0___default.a.writeFileSync('data/Courier-Bold.afm', pdfkit_js_data_Courier_Bold_afm__WEBPACK_IMPORTED_MODULE_1__["default"]);

/***/ }),

/***/ "./djsr/frontend/src/components/styles/katex.css":
/*!*******************************************************!*\
  !*** ./djsr/frontend/src/components/styles/katex.css ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "./djsr/frontend/src/components/taskSearch.js":
/*!****************************************************!*\
  !*** ./djsr/frontend/src/components/taskSearch.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _axiosAPI__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./axiosAPI */ "./djsr/frontend/src/components/axiosAPI.js");
/* harmony import */ var mdbreact__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! mdbreact */ "./node_modules/mdbreact/dist/mdbreact.esm.js");
/* harmony import */ var _FormikMDInput__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./FormikMDInput */ "./djsr/frontend/src/components/FormikMDInput.js");
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! formik */ "./node_modules/formik/dist/formik.esm.js");
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! yup */ "./node_modules/yup/es/index.js");
function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _createForOfIteratorHelper(o) { if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (o = _unsupportedIterableToArray(o))) { var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var it, normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(n); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { return function () { var Super = _getPrototypeOf(Derived), result; if (_isNativeReflectConstruct()) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








var TaskSearch = /*#__PURE__*/function (_Component) {
  _inherits(TaskSearch, _Component);

  var _super = _createSuper(TaskSearch);

  function TaskSearch(props) {
    var _this;

    _classCallCheck(this, TaskSearch);

    _this = _super.call(this, props);

    _defineProperty(_assertThisInitialized(_this), "toggleCollapse", function (id) {
      _this.setState({
        collapseId: id
      });
    });

    _defineProperty(_assertThisInitialized(_this), "compileSections", function () {
      var sections = _this.state.sections;
    });

    _this.state = {
      sections: null,
      collapseId: null,
      results: null
    };
    return _this;
  }

  _createClass(TaskSearch, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      _axiosAPI__WEBPACK_IMPORTED_MODULE_1__["axiosInstanceNoAuth"].get("/user/sections/").then(function (response) {
        _this2.setState({
          sections: response.data
        });
      })["catch"](function (error) {
        console.log(error);
      });
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      var sections = this.state.sections;
      var collapseId = this.state.collapseId;
      var results = this.state.results;
      console.log("sections", sections);
      if (!sections) return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, "loading");
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
        className: "w-100"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(formik__WEBPACK_IMPORTED_MODULE_4__["Formik"], {
        initialValues: {
          skills: []
        },
        onSubmit: function onSubmit(values, helpers) {
          setTimeout(function () {
            // console.log("start 1");
            helpers.setSubmitting(true); // console.log("start 2");

            var skills = values.skills;
            var result = [];

            var _iterator = _createForOfIteratorHelper(skills.keys()),
                _step;

            try {
              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                var key = _step.value;

                // result.push(key)
                if (!!skills[key]) {
                  result.push(key);
                }
              } // console.log("values",values);
              // console.log("skillsy",result.join(","));

            } catch (err) {
              _iterator.e(err);
            } finally {
              _iterator.f();
            }

            _axiosAPI__WEBPACK_IMPORTED_MODULE_1__["default"].post("/user/tasks/", {
              skill: result.join(",")
            }).then(function (response) {
              helpers.setSubmitting(false);
              console.log("response", response); // this.setState({
              //   results: response.data,
              // });

              _this3.props.updateData(response.data);
            })["catch"](function (error) {
              // console.log("login error", error.response);
              var errResponse = error.response;
              helpers.setSubmitting(false);
            });
          }, 200);
        }
      }, function (_ref) {
        var values = _ref.values,
            errors = _ref.errors,
            touched = _ref.touched,
            handleChange = _ref.handleChange,
            handleBlur = _ref.handleBlur,
            handleSubmit = _ref.handleSubmit,
            isSubmitting = _ref.isSubmitting;
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_2__["MDBContainer"], null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_2__["MDBContainer"], {
          className: "md-accordion mt-5"
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(formik__WEBPACK_IMPORTED_MODULE_4__["Form"], {
          onSubmit: handleSubmit
        }, sections.map(function (section) {
          return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
            className: "d-flex justify-content-between " + "p-2 mt-3 border-right border-top border-left " + (collapseId === "section-" + section.id ? "" : "border-bottom"),
            onClick: function onClick() {
              _this3.toggleCollapse("section-" + section.id);
            }
          }, section.Section, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_2__["MDBIcon"], {
            icon: collapseId === "section-" + section.id ? "angle-up" : "angle-down"
          })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_2__["MDBCollapse"], {
            id: "section-" + section.id,
            isOpen: collapseId,
            className: "border-left border-right border-bottom p-2"
          }, section.skill.map(function (skill) {
            return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
              className: "custom-control custom-checkbox"
            }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("input", {
              type: "checkbox",
              className: "custom-control-input",
              id: "skill-id-" + skill.id + "-" + section.id,
              value: true,
              name: "skills." + skill.id,
              onChange: handleChange,
              onBlur: handleBlur,
              disabled: isSubmitting
            }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("label", {
              className: "custom-control-label",
              htmlFor: "skill-id-" + skill.id + "-" + section.id
            }, skill.Skill));
          })));
        }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(mdbreact__WEBPACK_IMPORTED_MODULE_2__["MDBBtn"], {
          onClick: handleSubmit,
          disabled: isSubmitting
        }, "Szukaj", isSubmitting && /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
          className: "spinner-border spinner-border-sm",
          role: "status"
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
          className: "sr-only"
        }, "Loading..."))))));
      }));
    }
  }]);

  return TaskSearch;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]);

/* harmony default export */ __webpack_exports__["default"] = (TaskSearch);

/***/ }),

/***/ "./node_modules/pdfkit/js/data sync Helvetica.*\\.afm$":
/*!*************************************************************************!*\
  !*** ./node_modules/pdfkit/js/data sync nonrecursive Helvetica.*\.afm$ ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./Helvetica-Bold.afm": "./node_modules/pdfkit/js/data/Helvetica-Bold.afm",
	"./Helvetica-BoldOblique.afm": "./node_modules/pdfkit/js/data/Helvetica-BoldOblique.afm",
	"./Helvetica-Oblique.afm": "./node_modules/pdfkit/js/data/Helvetica-Oblique.afm",
	"./Helvetica.afm": "./node_modules/pdfkit/js/data/Helvetica.afm"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/pdfkit/js/data sync Helvetica.*\\.afm$";

/***/ })

}]);
//# sourceMappingURL=1.main.js.map